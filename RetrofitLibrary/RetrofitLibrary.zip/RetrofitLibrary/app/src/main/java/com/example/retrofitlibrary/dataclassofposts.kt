package com.example.retrofitlibrary

data class dataclassofposts(val userId:Int,val title:String,val body:String){

}
